/**
 * إعدادات التشغيل — يمكن استبدالها لاحقاً من لوحة الإدارة (site_settings).
 * بعد تدوير المفتاح ضع القيم الجديدة هنا.
 */
window.SITE_CONFIG = {
  SUPABASE_URL: "https://rnuzmpphrlrslydotfbd.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_e0d-Y-kwEYgTXfABoZXI8w_jPn38kQh",

  PHONES: ["782086041", "772007811", "778966609"],
  WHATSAPP: "",
  ADDRESS: "يريم - الدائري الغربي - تقاطع جولة غزة (سوق الأحد الجديد)",
  MAP_URL: "",

  LOCAL_PASSCODE: ""
};

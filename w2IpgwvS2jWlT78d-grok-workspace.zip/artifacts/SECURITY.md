# دليل الأمان — مستشفى د. حاشد الطبر

## الإصلاحات في الكود (Frontend)

1. تعطيل `LOCAL_PASSCODE` (فارغ) — لا دخول إدارة بدون Supabase Auth.
2. رفع ملفات: أنواع MIME مسموحة فقط + حد 8 ميجابايت.
3. قفل دخول الموظفين بعد 5 محاولات فاشلة (دقيقة).
4. قفل بحث تتبع الحجز بعد محاولات متكررة.
5. Content-Security-Policy + Referrer-Policy.
6. ملف `.gitignore` لمنع رفع الأسرار.

## إجراء إلزامي في Supabase

### أ) تدوير المفتاح
1. Dashboard → Project Settings → API  
2. Rotate / Reset لمفتاح **anon**  
3. حدّث `CONFIG.SUPABASE_ANON_KEY` في `index.html`  
4. لا تضع `service_role` في GitHub أبداً

### ب) تشغيل SQL
نفّذ الملف **`supabase-rls.sql`** كاملاً من SQL Editor.

يشمل:
- تفعيل RLS على كل الجداول
- سياسات قراءة/كتابة حسب الدور (`staff.id = auth.uid()`)
- دوال RPC آمنة:
  - `get_booking(ref, phone)` — تتبع بدون كشف كل الحجوزات
  - `cancel_booking(ref, phone)` — إلغاء من المريض
  - `taken_slots(doctor, from, to)` — المواعيد المحجوزة فقط

### ج) Storage bucket `media`
- القراءة: عامة (للصور في الموقع)
- الرفع/الحذف: `authenticated` فقط (يفضّل موظفين)

## تحقق بعد التطبيق

| اختبار | النتيجة المتوقعة |
|--------|-------------------|
| زائر: `from('staff').select()` | فارغ أو خطأ صلاحيات |
| زائر: `from('bookings').select()` | فارغ أو خطأ (لا قراءة عامة) |
| حجز جديد من النموذج | ينجح |
| تتبع برقم مرجع + جوال صحيح | يظهر الحجز |
| تتبع ببيانات خاطئة | لا يظهر شيء |
| دخول admin بحساب مربوط في `staff` | تفتح اللوحة |
| دخول بحساب Auth غير مربوط | رسالة «غير مرتبط بأي دور» |

## رفع إلى GitHub

```bash
git add index.html .gitignore SECURITY.md supabase-rls.sql
git commit -m "security: harden auth, uploads, RLS and booking RPCs"
git push
```

## ملاحظات

- مفتاح **anon** يظهر في المتصفح دائماً — هذا طبيعي.
- الحماية الحقيقية = **RLS + RPC + Auth**.
- الوضع المحلي للتجربة فقط: عيّن `LOCAL_PASSCODE` قوياً على جهازك ولا ترفعه.

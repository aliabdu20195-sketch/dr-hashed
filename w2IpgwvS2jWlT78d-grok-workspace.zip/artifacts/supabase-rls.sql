-- =============================================================================
-- أمان قاعدة البيانات — مستشفى د. حاشد الطبر
-- نفّذ في Supabase → SQL Editor
-- مبني على الكود الفعلي: staff.id = auth.uid()
-- =============================================================================

ALTER TABLE IF EXISTS public.clinics ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.doctor_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.media_gallery ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.news ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.staff ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.current_staff_role()
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM public.staff WHERE id = auth.uid() LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.is_staff_admin()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.staff WHERE id = auth.uid() AND role = 'admin');
$$;

CREATE OR REPLACE FUNCTION public.is_staff_member()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.staff WHERE id = auth.uid());
$$;

CREATE OR REPLACE FUNCTION public.is_staff_reception_or_admin()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.staff WHERE id = auth.uid() AND role IN ('admin', 'reception'));
$$;

DROP POLICY IF EXISTS "clinics_public_read" ON public.clinics;
CREATE POLICY "clinics_public_read" ON public.clinics
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "clinics_admin_write" ON public.clinics;
CREATE POLICY "clinics_admin_write" ON public.clinics
  FOR ALL TO authenticated
  USING (public.is_staff_admin()) WITH CHECK (public.is_staff_admin());

DROP POLICY IF EXISTS "bookings_anon_insert" ON public.bookings;
CREATE POLICY "bookings_anon_insert" ON public.bookings
  FOR INSERT TO anon, authenticated WITH CHECK (status = 'pending');

DROP POLICY IF EXISTS "bookings_staff_select" ON public.bookings;
CREATE POLICY "bookings_staff_select" ON public.bookings
  FOR SELECT TO authenticated USING (public.is_staff_member());

DROP POLICY IF EXISTS "bookings_staff_update" ON public.bookings;
CREATE POLICY "bookings_staff_update" ON public.bookings
  FOR UPDATE TO authenticated
  USING (public.is_staff_reception_or_admin())
  WITH CHECK (public.is_staff_reception_or_admin());

DROP POLICY IF EXISTS "bookings_admin_delete" ON public.bookings;
CREATE POLICY "bookings_admin_delete" ON public.bookings
  FOR DELETE TO authenticated USING (public.is_staff_admin());

DROP POLICY IF EXISTS "doctor_profiles_public_read" ON public.doctor_profiles;
CREATE POLICY "doctor_profiles_public_read" ON public.doctor_profiles
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "doctor_profiles_admin_all" ON public.doctor_profiles;
CREATE POLICY "doctor_profiles_admin_all" ON public.doctor_profiles
  FOR ALL TO authenticated
  USING (public.is_staff_admin()) WITH CHECK (public.is_staff_admin());

DROP POLICY IF EXISTS "doctor_profiles_self_insert" ON public.doctor_profiles;
CREATE POLICY "doctor_profiles_self_insert" ON public.doctor_profiles
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.staff s
    WHERE s.id = auth.uid() AND s.role = 'doctor' AND s.doctor_name = doctor_profiles.doctor_name
  ));

DROP POLICY IF EXISTS "doctor_profiles_self_update" ON public.doctor_profiles;
CREATE POLICY "doctor_profiles_self_update" ON public.doctor_profiles
  FOR UPDATE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.staff s
    WHERE s.id = auth.uid() AND s.role = 'doctor' AND s.doctor_name = doctor_profiles.doctor_name
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.staff s
    WHERE s.id = auth.uid() AND s.role = 'doctor' AND s.doctor_name = doctor_profiles.doctor_name
  ));

DROP POLICY IF EXISTS "media_public_read" ON public.media_gallery;
CREATE POLICY "media_public_read" ON public.media_gallery
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "media_admin_write" ON public.media_gallery;
CREATE POLICY "media_admin_write" ON public.media_gallery
  FOR ALL TO authenticated
  USING (public.is_staff_reception_or_admin())
  WITH CHECK (public.is_staff_reception_or_admin());

DROP POLICY IF EXISTS "activities_public_read" ON public.activities;
CREATE POLICY "activities_public_read" ON public.activities
  FOR SELECT TO anon, authenticated
  USING (COALESCE(published, false) = true OR public.is_staff_member());

DROP POLICY IF EXISTS "activities_admin_write" ON public.activities;
CREATE POLICY "activities_admin_write" ON public.activities
  FOR ALL TO authenticated
  USING (public.is_staff_reception_or_admin())
  WITH CHECK (public.is_staff_reception_or_admin());

DROP POLICY IF EXISTS "news_public_read" ON public.news;
CREATE POLICY "news_public_read" ON public.news
  FOR SELECT TO anon, authenticated
  USING (COALESCE(published, false) = true OR public.is_staff_member());

DROP POLICY IF EXISTS "news_admin_write" ON public.news;
CREATE POLICY "news_admin_write" ON public.news
  FOR ALL TO authenticated
  USING (public.is_staff_reception_or_admin())
  WITH CHECK (public.is_staff_reception_or_admin());

DROP POLICY IF EXISTS "staff_self_read" ON public.staff;
CREATE POLICY "staff_self_read" ON public.staff
  FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.is_staff_admin());

DROP POLICY IF EXISTS "staff_admin_write" ON public.staff;
CREATE POLICY "staff_admin_write" ON public.staff
  FOR ALL TO authenticated
  USING (public.is_staff_admin()) WITH CHECK (public.is_staff_admin());

CREATE OR REPLACE FUNCTION public.get_booking(p_ref text, p_phone text)
RETURNS TABLE (
  ref text, request_type text, name text, clinic_name text,
  doctor text, slot_label text, status text
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  RETURN QUERY
  SELECT b.ref::text, b.request_type::text, b.name::text, b.clinic_name::text,
         b.doctor::text, b.slot_label::text, b.status::text
  FROM public.bookings b
  WHERE upper(trim(b.ref)) = upper(trim(p_ref))
    AND regexp_replace(coalesce(b.phone,''), '\D', '', 'g')
      = regexp_replace(coalesce(p_phone,''), '\D', '', 'g')
  LIMIT 1;
END;
$$;

CREATE OR REPLACE FUNCTION public.cancel_booking(p_ref text, p_phone text)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE updated_count int;
BEGIN
  UPDATE public.bookings b
  SET status = 'cancelled'
  WHERE upper(trim(b.ref)) = upper(trim(p_ref))
    AND regexp_replace(coalesce(b.phone,''), '\D', '', 'g')
      = regexp_replace(coalesce(p_phone,''), '\D', '', 'g')
    AND b.status IN ('pending', 'confirmed');
  GET DIAGNOSTICS updated_count = ROW_COUNT;
  RETURN updated_count > 0;
END;
$$;

CREATE OR REPLACE FUNCTION public.taken_slots(p_doctor text, p_from date, p_to date)
RETURNS TABLE (slot_date date, slot_time text)
LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT b.slot_date, left(b.slot_time::text, 5) AS slot_time
  FROM public.bookings b
  WHERE b.doctor = p_doctor
    AND b.slot_date IS NOT NULL
    AND b.slot_date BETWEEN p_from AND p_to
    AND b.status IS DISTINCT FROM 'cancelled';
$$;

GRANT EXECUTE ON FUNCTION public.get_booking(text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_booking(text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.taken_slots(text, date, date) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.current_staff_role() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_staff_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_staff_member() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_staff_reception_or_admin() TO authenticated;

-- =============================================================================
-- جداول وإضافات: إعدادات الموقع + حقول الأطباء
-- =============================================================================

CREATE TABLE IF NOT EXISTS public.site_settings (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  phones text[] DEFAULT '{}',
  whatsapp text,
  address text,
  map_url text,
  work_days int[] DEFAULT ARRAY[6,0,1,2,3,4],
  time_slots jsonb DEFAULT '[{"v":"09:00","l":"09:00 ص"},{"v":"11:00","l":"11:00 ص"},{"v":"13:00","l":"01:00 م"},{"v":"16:00","l":"04:00 م"},{"v":"18:00","l":"06:00 م"}]'::jsonb,
  min_lead_minutes int DEFAULT 30,
  updated_at timestamptz DEFAULT now()
);

INSERT INTO public.site_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

ALTER TABLE IF EXISTS public.doctor_profiles ADD COLUMN IF NOT EXISTS specialty text;
ALTER TABLE IF EXISTS public.doctor_profiles ADD COLUMN IF NOT EXISTS active boolean DEFAULT true;

ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "site_settings_public_read" ON public.site_settings;
CREATE POLICY "site_settings_public_read" ON public.site_settings
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "site_settings_admin_write" ON public.site_settings;
CREATE POLICY "site_settings_admin_write" ON public.site_settings
  FOR ALL TO authenticated
  USING (public.is_staff_admin())
  WITH CHECK (public.is_staff_admin());

/**
 * انسخ هذا الملف إلى config.js وعدّل القيم.
 * ارفع config.js إلى GitHub Pages إن لزم للتشغيل،
 * أو استخدم GitHub Actions لحقن الأسرار عند النشر.
 *
 * لا تضع service_role هنا أبداً.
 */
window.SITE_CONFIG = {
  SUPABASE_URL: "https://YOUR_PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_ANON_OR_PUBLISHABLE_KEY",

  // اختياري — تُحمَّل أيضاً من جدول site_settings إن وُجد
  PHONES: [],
  WHATSAPP: "",
  ADDRESS: "",
  MAP_URL: "",

  // وضع التجربة المحلي فقط (لا ترفع رمزاً حقيقياً)
  LOCAL_PASSCODE: ""
};
